﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DibujarCirculo
{

    public partial class Figuras : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           

           string pFigura =  ddFigura.SelectedValue; 

            svcCalcularFigura.Service1Client ObjSvc = new svcCalcularFigura.Service1Client();
            string Res = ObjSvc.CalcularFigura(castDecimal(txtAlto.Text), castDecimal(txtBase.Text), castDecimal(txtRadio.Text), castDecimal(txtAncho.Text), castDecimal(txtLargo.Text), pFigura);
            lblResultado.Text = Res;


            ScriptManager.RegisterStartupScript(this, typeof(Page), "myfunction", "myfunction();", true);
        }

        protected decimal castDecimal(string pNumeri)
        {
        
            decimal numero;
            decimal.TryParse(pNumeri, out numero);
            return numero;
        }
    }
}