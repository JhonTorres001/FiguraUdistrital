﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfCalculoGeometrico
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public string CalcularFigura(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo,  string pFigura)
        {

            var userStrategy = pFigura;
            string res = string.Empty;
            //Console.WriteLine("\nUser has selected *" + userStrategy + "* as mode of transport\n");
            //Console.WriteLine("\n*****************************************************************************************************\n");

            switch (userStrategy)
            {
                case "Cuadrado":
                    res = new FiguraStrategy(new CuadradoStrategy()).GetTravelTime( pAltura,  pBase,  pRadio,  pAncho,  pLargo);
                    break;
                case "Circulo":
                    res =  new FiguraStrategy(new CirculoStrategy()).GetTravelTime(pAltura, pBase, pRadio, pAncho, pLargo);
                    break;
                case "Triangulo":
                    res=  new FiguraStrategy(new TrianguloStrategy()).GetTravelTime(pAltura, pBase, pRadio, pAncho, pLargo);
                    break;
                case "Rectangulo":
                    res = new FiguraStrategy(new RectanguloStrategy()).GetTravelTime(pAltura, pBase, pRadio, pAncho, pLargo);
                    break;
                default:                
                    break;
            }
            return res;


        }

        public string CalcularFigura(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo, string pFigur,  string pFigura)
        {
            throw new NotImplementedException();
        }

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public interface IStrategy
        {
            string GetTravelTime(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo);
        }

        public class TrianguloStrategy : IStrategy
        {

            public string GetTravelTime(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo)
            {
                return "Area:" + ((pBase * pAltura) / 2).ToString() + " Perimetro:" + (Math.Sqrt(Math.Pow((double)pAltura, 2) + Math.Pow((double)pBase, 2)) + (double)pAltura + (double)pBase);
            }
        }

        public class CuadradoStrategy : IStrategy
        {

            public string GetTravelTime(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo)
            {
                return "Area:" + (pAltura * pAltura).ToString() + " Perimetro:" + (pAltura * 4).ToString();


                //return string.Empty;
            }
        }

        public class CirculoStrategy : IStrategy
        {

            public string GetTravelTime(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo)
            {
                return "Area:" + (Math.PI * Math.Pow((double)pRadio, 2)).ToString() + " Perimetro:" + Math.PI * (2 * (double)pRadio);
            }
        }

        public class RectanguloStrategy : IStrategy
        {

            public string GetTravelTime(decimal pAltura, decimal pBase, decimal pRadio, decimal pAncho, decimal pLargo)
            {
                return "Area:" + (pAltura * pBase) + " Perimetro:" + ((pAltura * 2) + (pBase * 2));
            }
        }

        public class FiguraStrategy
        {
            private IStrategy _strategy;

            public FiguraStrategy(IStrategy chosenStrategy)
            {
                _strategy = chosenStrategy;
            }

            public string GetTravelTime(decimal pAltura = 0, decimal pBase = 0, decimal pRadio = 0, decimal pAncho = 0, decimal pLargo = 0)
            {

                return  _strategy.GetTravelTime(pAltura, pBase, pRadio, pAncho, pLargo);
                //Console.WriteLine(result);
                //Console.ReadLine();
            }
        }

    }
}
